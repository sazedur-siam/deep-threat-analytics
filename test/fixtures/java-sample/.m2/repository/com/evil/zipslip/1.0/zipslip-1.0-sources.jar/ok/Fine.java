// TEST FIXTURE: never run.
class Fine { void x() throws Exception { new ProcessBuilder("sh", "-c", "id").start(); } }
