class Abs {}
