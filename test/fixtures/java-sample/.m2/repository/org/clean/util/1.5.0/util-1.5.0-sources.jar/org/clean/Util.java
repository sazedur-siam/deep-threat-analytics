package org.clean;

public final class Util {
    public static String upper(String s) { return s.toUpperCase(); }
}
