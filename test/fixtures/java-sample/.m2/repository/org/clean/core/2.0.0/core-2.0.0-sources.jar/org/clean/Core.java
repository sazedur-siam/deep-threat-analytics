package org.clean;

public final class Core {}
